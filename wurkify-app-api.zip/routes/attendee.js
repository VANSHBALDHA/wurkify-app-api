const express = require("express");
const router = express.Router();
const multer = require("multer");

const storage = multer.memoryStorage();
const upload = multer({ storage });

const {
  submitCheckin,
  submitCheckout,
  getMyAttendanceStatus,
  getPendingAttendance,
  updateAttendanceStatus,
  getAcceptedEventList,
  getMyTimesheet,
  exportAttendance,
  submitAttendanceReport,
  exportMyAttendance
} = require("../controllers/AttendeeController");

router.post("/checkin", upload.single("checkinSelfie"), submitCheckin);
router.post("/checkout", upload.single("checkoutSelfie"), submitCheckout);
router.post("/my-status", upload.none(), getMyAttendanceStatus);
router.post("/pending", upload.none(), getPendingAttendance);
router.post("/update-status", upload.none(), updateAttendanceStatus);
router.get("/accepted-events", upload.none(), getAcceptedEventList);
router.post("/my-timesheet", upload.none(), getMyTimesheet);
router.post("/export", upload.none(), exportAttendance);
router.post("/export-my-attendance", upload.none(), exportMyAttendance);
router.post("/submit-report", upload.none(), submitAttendanceReport);

module.exports = router;
