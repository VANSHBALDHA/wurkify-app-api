const jwt = require("jsonwebtoken");
const mongoose = require("mongoose");
const AttendeeCheckin = require("../models/AttendeeCheckin");
const Event = require("../models/Event");
const UserAuth = require("../models/AuthUsers");
const EventApplication = require("../models/EventApplication");
const { sendNotification } = require("../middlewares/notificationService");
const UserProfile = require("../models/UserProfile");
const cloudinary = require("cloudinary").v2;
const streamifier = require("streamifier");
const { format } = require("date-fns");
const { seekerMessages } = require("../utils/seekerNotifications");
const { organizerMessages } = require("../utils/organizerNotifications");
const { Parser } = require("json2csv");

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const JWT_SECRET = process.env.JWT_SECRET || "wurkifyapp";

const calculateDuration = (checkinTime, checkoutTime) => {
  if (!checkinTime || !checkoutTime) return null;
  const diffMs = new Date(checkoutTime) - new Date(checkinTime);
  const hours = Math.floor(diffMs / 3600000);
  const mins = Math.floor((diffMs % 3600000) / 60000);
  return { hours, mins, totalMinutes: hours * 60 + mins };
};

const formatDateTime = (date) =>
  date ? format(new Date(date), "dd-MM-yyyy hh:mm:ss a") : null;

const submitCheckin = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    const userId = decoded._id;
    const { eventId, lat, lng } = req.body;

    if (!eventId || !req.file || !lat || !lng) {
      return res.status(400).json({
        success: false,
        message: "eventId, selfie & GPS location required",
      });
    }

    const event = await Event.findById(eventId);
    if (!event)
      return res
        .status(404)
        .json({ success: false, message: "Event not found" });

    const result = await new Promise((resolve, reject) => {
      const stream = cloudinary.uploader.upload_stream(
        { folder: "attendance_checkins" },
        (err, result) => (err ? reject(err) : resolve(result)),
      );
      streamifier.createReadStream(req.file.buffer).pipe(stream);
    });

    const now = new Date();

    const checkin = await AttendeeCheckin.findOneAndUpdate(
      { eventId, userId },
      {
        $push: {
          sessions: {
            checkinSelfie: result.secure_url,
            checkinTime: new Date(),
            checkinStatus: "pending",
            attendanceDate: now,
            checkinLocation: { lat, lng },
          },
        },
      },
      { new: true, upsert: true },
    );

    const seekerName = decoded.name || "An attendee";
    const orgTemplate = organizerMessages.attendanceCheckin(
      event.eventName,
      seekerName,
    );

    await sendNotification({
      sender_id: userId,
      receiver_id: event.organizer_id,
      event_id: eventId,
      type: "checkin",
      title: orgTemplate.title,
      message: orgTemplate.message,
    });

    const seekerTemplate = seekerMessages.checkinSubmitted(event.eventName);

    await sendNotification({
      sender_id: event.organizer_id,
      receiver_id: userId,
      event_id: eventId,
      type: "checkin",
      title: seekerTemplate.title,
      message: seekerTemplate.message,
    });

    res.status(201).json({
      success: true,
      message: "Check-in submitted successfully",
      checkin,
    });
  } catch (err) {
    console.error("Submit Check-in Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

const submitCheckout = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    const userId = decoded._id;
    const { eventId, lat, lng } = req.body;

    if (!eventId || !req.file || !lat || !lng) {
      return res.status(400).json({
        success: false,
        message: "eventId, selfie & GPS location required",
      });
    }

    const record = await AttendeeCheckin.findOne({ eventId, userId });
    if (!record || !record.sessions.length)
      return res.status(400).json({
        success: false,
        message: "You must check-in before check-out",
      });

    const last = record.sessions[record.sessions.length - 1];
    if (last.checkoutTime)
      return res
        .status(400)
        .json({ success: false, message: "No active check-in to checkout" });
    if (last.checkinStatus !== "approved")
      return res.status(400).json({
        success: false,
        message: "Check-in must be approved before checking out",
      });

    const result = await new Promise((resolve, reject) => {
      const stream = cloudinary.uploader.upload_stream(
        { folder: "attendance_checkouts" },
        (err, result) => (err ? reject(err) : resolve(result)),
      );
      streamifier.createReadStream(req.file.buffer).pipe(stream);
    });

    const checkoutTime = new Date();
    const diffMinutes = (checkoutTime - new Date(last.checkinTime)) / 60000;

    last.checkoutSelfie = result.secure_url;
    last.checkoutTime = checkoutTime;
    last.checkoutLocation = { lat, lng };
    last.checkoutStatus = "pending";
    last.durationMinutes = Math.round(diffMinutes);

    await record.save();

    const event = await Event.findById(eventId);

    await sendNotification({
      sender_id: userId,
      receiver_id: event.organizer_id,
      event_id: eventId,
      type: "checkout",
      title: "New Check-out Request",
      message: `${decoded.name || "An attendee"} has checked out for "${
        event.eventName
      }" awaiting your approval.`,
    });

    const seekerTemplate = seekerMessages.checkoutSubmitted(event.eventName);

    await sendNotification({
      sender_id: event.organizer_id,
      receiver_id: userId,
      event_id: eventId,
      type: "checkout",
      title: seekerTemplate.title,
      message: seekerTemplate.message,
    });

    res.status(201).json({
      success: true,
      message: "Check-out submitted successfully",
      attendee: record,
    });
  } catch (err) {
    console.error("Submit Checkout Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

const getMyAttendanceStatus = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    const { eventId } = req.body;

    const record = await AttendeeCheckin.findOne({
      eventId,
      userId: decoded._id,
    });
    if (!record || !record.sessions.length)
      return res
        .status(404)
        .json({ success: false, message: "No attendance found" });

    const last = record.sessions[record.sessions.length - 1];
    res.status(200).json({
      success: true,
      attendance: {
        checkinStatus: last.checkinStatus,
        checkinTime: formatDateTime(last.checkinTime),
        checkoutStatus: last.checkoutStatus,
        checkoutTime: formatDateTime(last.checkoutTime),
        duration: calculateDuration(last.checkinTime, last.checkoutTime),
      },
    });
  } catch (err) {
    console.error("Get My Attendance Status Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

const getPendingAttendance = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    const organizerId = decoded._id;
    const { eventId } = req.body;

    const event = await Event.findOne({
      _id: eventId,
      organizer_id: organizerId,
    });
    if (!event)
      return res
        .status(403)
        .json({ success: false, message: "Unauthorized event access" });

    const records = await AttendeeCheckin.find({ eventId }).populate(
      "userId",
      "name email",
    );

    const pending = [];
    for (const r of records) {
      const profile = await UserProfile.findOne({
        userId: r.userId._id,
      }).select("profile_img");
      for (const s of r.sessions) {
        if (s.checkinStatus === "pending" || s.checkoutStatus === "pending") {
          pending.push({
            recordId: r._id,
            user: {
              _id: r.userId._id,
              name: r.userId.name,
              email: r.userId.email,
              profile_img: profile?.profile_img || null,
            },
            sessionId: s._id,
            checkinTime: formatDateTime(s.checkinTime),
            checkoutTime: formatDateTime(s.checkoutTime),
            checkinSelfie: s.checkinSelfie,
            checkoutSelfie: s.checkoutSelfie,
            checkinStatus: s.checkinStatus,
            checkoutStatus: s.checkoutStatus,
            duration: calculateDuration(s.checkinTime, s.checkoutTime),
          });
        }
      }
    }

    res.status(200).json({ success: true, records: pending });
  } catch (err) {
    console.error("Get Pending Attendance Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

const updateAttendanceStatus = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    const { recordId, sessionId, type, status } = req.body;

    const record = await AttendeeCheckin.findOneAndUpdate(
      { _id: recordId, "sessions._id": sessionId },
      { $set: { [`sessions.$.${type}Status`]: status } },
      { new: true },
    ).populate("userId", "name email");

    if (!record)
      return res
        .status(404)
        .json({ success: false, message: "Record not found" });

    const event = await Event.findById(record.eventId);

    let template;

    if (type === "checkin") {
      template =
        status === "approved"
          ? seekerMessages.checkinApproved(event.eventName)
          : seekerMessages.checkinRejected(event.eventName);
    } else if (type === "checkout") {
      template =
        status === "approved"
          ? seekerMessages.checkoutApproved(event.eventName)
          : seekerMessages.checkoutRejected(event.eventName);
    }

    await sendNotification({
      sender_id: decoded._id,
      receiver_id: record.userId._id,
      event_id: event._id,
      type: "attendance",
      title: template.title,
      message: template.message,
    });

    res.status(200).json({
      success: true,
      message: `${type} ${status}`,
      record,
    });
  } catch (err) {
    console.error("Update Attendance Status Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

const getAcceptedEventList = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    const applications = await EventApplication.find({
      seeker_id: decoded._id,
      applicationStatus: "accepted",
    }).populate("event_id", "eventName location eventStatus");

    res.status(200).json({
      success: true,
      events: applications.map((a) => ({
        event_id: a.event_id?._id,
        eventName: a.event_id?.eventName,
        location: a.event_id?.location,
        eventStatus: a.event_id?.eventStatus,
        appliedAt: a.appliedAt,
      })),
    });
  } catch (err) {
    console.error("Get Accepted Event List Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

const getMyTimesheet = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    const { eventId } = req.body;

    const record = await AttendeeCheckin.findOne({
      eventId,
      userId: decoded._id,
    });

    if (!record || !record.sessions.length) {
      return res.status(200).json({
        success: true,
        timesheet: [
          {
            checkinTime: "00:00",
            checkoutTime: "00:00",
            checkinStatus: "none",
            checkoutStatus: "none",
            checkinSelfie: null,
            checkoutSelfie: null,
            totalHours: "0.00",
          },
        ],
        uiState: {
          canCheckin: true,
          canCheckout: false,
          message: "You have not checked in yet.",
        },
      });
    }

    const timesheet = record.sessions.map((s) => ({
      checkinTime: formatDateTime(s.checkinTime),
      checkoutTime: formatDateTime(s.checkoutTime),
      checkinStatus: s.checkinStatus,
      checkoutStatus: s.checkoutStatus,
      checkinSelfie: s.checkinSelfie || null,
      checkoutSelfie: s.checkoutSelfie || null,
      totalHours:
        s.checkinTime && s.checkoutTime
          ? (
              (new Date(s.checkoutTime) - new Date(s.checkinTime)) /
              3600000
            ).toFixed(2)
          : "0.00",
    }));

    const last = record.sessions[record.sessions.length - 1];

    let canCheckin = false;
    let canCheckout = false;
    let message = "";

    if (!last.checkinTime) {
      // just in case
      canCheckin = true;
      message = "You can check in.";
    } else if (!last.checkoutTime) {
      // user has checked in but not checked out yet
      if (last.checkinStatus === "approved") {
        canCheckout = true;
        message = "Your check-in is approved. You can check out.";
      } else if (last.checkinStatus === "pending") {
        canCheckin = false;
        canCheckout = false;
        message = "Your check-in is pending approval.";
      } else if (last.checkinStatus === "rejected") {
        // maybe allow re-check-in?
        canCheckin = true;
        message = "Your check-in was rejected. Please check in again.";
      }
    } else {
      // both checkin & checkout done → allow new check-in
      canCheckin = true;
      message = "You have completed your last session. You can check in again.";
    }

    res.status(200).json({
      success: true,
      timesheet,
      uiState: {
        canCheckin,
        canCheckout,
        message,
      },
    });
  } catch (err) {
    console.error("Get My Timesheet Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

const exportAttendance = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    const organizerId = decoded._id;
    const { eventId } = req.body;

    if (!eventId) {
      return res.status(400).json({
        success: false,
        message: "eventId is required",
      });
    }

    const event = await Event.findOne({
      _id: eventId,
      organizer_id: organizerId,
    });

    if (!event) {
      return res.status(403).json({
        success: false,
        message: "Unauthorized access",
      });
    }

    const records = await AttendeeCheckin.find({ eventId }).populate(
      "userId",
      "name email",
    );

    const rows = [];

    records.forEach((r) => {
      r.sessions.forEach((s) => {
        const duration = calculateDuration(s.checkinTime, s.checkoutTime);

        rows.push({
          Event: event.eventName,
          Name: r.userId.name,
          Email: r.userId.email,
          "Check-in Time": formatDateTime(s.checkinTime),
          "Check-out Time": formatDateTime(s.checkoutTime),
          "Check-in Status": s.checkinStatus,
          "Check-out Status": s.checkoutStatus,
          "Total Minutes": duration?.totalMinutes || 0,
        });
      });
    });

    const parser = new Parser();
    const csv = parser.parse(rows);

    res.header("Content-Type", "text/csv");
    res.header(
      "Content-Disposition",
      `attachment; filename=attendance_${eventId}.csv`,
    );

    return res.send(csv);
  } catch (err) {
    console.error("Export Attendance Error:", err);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

const submitAttendanceReport = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET);

    const { recordId, sessionId, message } = req.body;

    if (!message)
      return res
        .status(400)
        .json({ success: false, message: "Report message required" });

    const record = await AttendeeCheckin.findOneAndUpdate(
      { _id: recordId, "sessions._id": sessionId },
      {
        $set: {
          "sessions.$.report": {
            message,
            createdAt: new Date(),
          },
        },
      },
      { new: true },
    );

    res.status(200).json({
      success: true,
      message: "Report submitted successfully",
    });
  } catch (err) {
    console.error("Submit Report Error:", err);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

const exportMyAttendance = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    const decoded = jwt.verify(token, JWT_SECRET);
    const userId = decoded._id;
    const { eventId } = req.body;

    if (!eventId) {
      return res.status(400).json({
        success: false,
        message: "eventId is required",
      });
    }

    const event = await Event.findById(eventId);
    if (!event) {
      return res.status(404).json({ success: false, message: "Event not found" });
    }

    const record = await AttendeeCheckin.findOne({ eventId, userId });

    if (!record || !record.sessions.length) {
      return res.status(404).json({ success: false, message: "No attendance found for this event" });
    }

    const rows = [];

    record.sessions.forEach((s) => {
      const duration = calculateDuration(s.checkinTime, s.checkoutTime);
      rows.push({
        Event: event.eventName,
        "Check-in Time": formatDateTime(s.checkinTime) || "-",
        "Check-out Time": formatDateTime(s.checkoutTime) || "-",
        "Check-in Status": s.checkinStatus,
        "Check-out Status": s.checkoutStatus,
        "Total Minutes": duration?.totalMinutes || 0,
      });
    });

    const parser = new Parser();
    const csv = parser.parse(rows);

    res.header("Content-Type", "text/csv");
    res.header(
      "Content-Disposition",
      `attachment; filename=my_attendance_${eventId}.csv`,
    );

    return res.send(csv);
  } catch (err) {
    console.error("Export My Attendance Error:", err);
    res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};

module.exports = {
  submitCheckin,
  submitCheckout,
  getMyAttendanceStatus,
  getPendingAttendance,
  updateAttendanceStatus,
  getAcceptedEventList,
  getMyTimesheet,
  exportAttendance,
  submitAttendanceReport,
  exportMyAttendance,
};
